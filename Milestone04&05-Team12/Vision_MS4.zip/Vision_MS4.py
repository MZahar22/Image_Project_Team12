import cv2
import numpy as np
import time
import os
import sys
import select
import tty
import termios

def main():
    # 1. Initialize webcam (0 is usually the built-in laptop webcam or USB cam on Raspberry Pi)
    cap = cv2.VideoCapture(0)
    
    # Check if the webcam is opened correctly
    if not cap.isOpened():
        print("Error: Could not open webcam.")
        return

    # --- FOLDER SETUP ---
    save_folder = "captured_images"
    if not os.path.exists(save_folder):
        os.makedirs(save_folder)
        print(f"Created new directory: {save_folder}")

    # --- COLOR PROFILES ---
    # These values have been widened and adjusted for the hazy/dim lighting 
    # seen in the Raspberry Pi camera feed.
    color_profiles = {
        "green": {
            "lower": np.array([45, 40, 40]),
            "upper": np.array([85, 255, 255])
        },
        "purple": {
            # Purple is very washed out in this lighting, making it risky
            "lower": np.array([125, 40, 40]),
            "upper": np.array([165, 255, 255])
        },
        "blue": {
            # Blue retains its hue best in this dim lighting
            "lower": np.array([95, 60, 40]),
            "upper": np.array([130, 255, 255])
        }
    }

    # Selected BLUE because Purple blends into shadows in this lighting, 
    # and Green risks picking up your floor tiles.
    target_color = "blue"
    lower_color = color_profiles[target_color]["lower"]
    upper_color = color_profiles[target_color]["upper"]

    print(f"--- HEADLESS MODE ACTIVATED ---")
    print(f"Tracking {target_color} ball over SSH.")
    print("Coordinates will print here. An image will automatically save every 3 seconds if the ball is seen.")
    print("Press 's' in this terminal to MANUALLY save an image.")
    print("Press 'q' or Ctrl+C in this terminal to QUIT.")

    last_save_time = 0
    save_cooldown = 3.0 # Save an image maximum once every 3 seconds

    # Save current terminal settings to restore them later
    old_settings = termios.tcgetattr(sys.stdin)
    tty.setcbreak(sys.stdin.fileno())

    try:
        while True:
            # Read the frame from the camera
            ret, frame = cap.read()
            if not ret:
                print("Failed to grab frame.")
                break

            # Resize the frame for Raspberry Pi performance
            frame = cv2.resize(frame, (640, 480))

            # Convert to HSV and create mask
            hsv_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
            mask = cv2.inRange(hsv_frame, lower_color, upper_color)

            # Morphological Operations to reduce noise
            kernel = np.ones((5, 5), np.uint8)
            mask = cv2.erode(mask, kernel, iterations=1)
            mask = cv2.dilate(mask, kernel, iterations=2)

            # Find Contours
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            # Find the largest contour and calculate its Centroid
            if len(contours) > 0:
                largest_contour = max(contours, key=cv2.contourArea)
                
                if cv2.contourArea(largest_contour) > 500:
                    M = cv2.moments(largest_contour)
                    
                    if M["m00"] != 0:
                        cx = int(M["m10"] / M["m00"])
                        cy = int(M["m01"] / M["m00"])
                        
                        ((x, y), radius) = cv2.minEnclosingCircle(largest_contour)
                        cv2.circle(frame, (int(x), int(y)), int(radius), (0, 255, 255), 2)
                        cv2.circle(frame, (cx, cy), 5, (0, 0, 255), -1)
                        cv2.putText(frame, f"Centroid: ({cx}, {cy})", (cx - 50, cy - 20),
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)

                        # Print to SSH terminal so you know it's working
                        print(f"[{time.strftime('%H:%M:%S')}] Ball detected at Centroid: ({cx}, {cy})")

                        # Auto-save logic
                        current_time = time.time()
                        if current_time - last_save_time > save_cooldown:
                            timestamp = time.strftime("%Y%m%d-%H%M%S")
                            filename = f"auto_capture_{timestamp}.jpg"
                            filepath = os.path.join(save_folder, filename)
                            
                            # Save the frame
                            cv2.imwrite(filepath, frame)
                            print(f" --> AUTO-SUCCESS: Image saved to {filepath}")
                            
                            last_save_time = current_time

            # Check for keyboard input in the SSH terminal (Non-blocking)
            if select.select([sys.stdin], [], [], 0)[0]:
                key = sys.stdin.read(1)
                if key.lower() == 's':
                    # Manual save triggered by pressing 's'
                    timestamp = time.strftime("%Y%m%d-%H%M%S")
                    filename = f"manual_capture_{timestamp}.jpg"
                    filepath = os.path.join(save_folder, filename)
                    cv2.imwrite(filepath, frame)
                    print(f"\n ---> MANUAL SAVE SUCCESS: Image saved to {filepath} <--- \n")
                elif key.lower() == 'q':
                    print("\n'q' pressed. Exiting...")
                    break

    except KeyboardInterrupt:
        # This block catches the Ctrl+C command to stop the script nicely
        print("\nScript stopped by user (Ctrl+C).")

    finally:
        # Restore normal terminal behavior so your SSH session doesn't break
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)
        
        # Clean up
        cap.release()
        print("Webcam turned off. Goodbye!")

if __name__ == "__main__":
    main()
