import rclpy
from rclpy.node import Node
import serial
import cv2
import numpy as np
import time
import os
import sys
import select
import termios
import tty
from collections import deque

class AutonomousVisionNode(Node):
    def __init__(self):
        super().__init__('autonomous_vision_node')
        
        # --- 1. SERIAL SETUP (Arduino) ---
        self.arduino_port = '/dev/ttyACM0'
        self.baud_rate = 115200
        try:
            self.ser = serial.Serial(self.arduino_port, self.baud_rate, timeout=0.05)
            self.get_logger().info('Serial connection established with Arduino.')
        except serial.SerialException:
            self.get_logger().error('Could not open serial port. Check Arduino connection!')
            sys.exit(1)
            
        self.target_rpm = 200 # <-- CHANGED: Starts automatically at 200 PWM to overcome friction!
        self.actual_rpm = 0.0 # Store encoder feedback
        self.steering = 90 # Default straight
        
        # --- 2. CAMERA SETUP ---
        self.cap = cv2.VideoCapture(0)
        if not self.cap.isOpened():
            self.get_logger().error("Could not open webcam.")
            sys.exit(1)
            
        # --- 3. VISION PARAMETERS ---
        self.save_folder = "captured_images"
        if not os.path.exists(self.save_folder):
            os.makedirs(self.save_folder)
            
        # Blue ball color profile (tuned for dim Raspberry Pi lighting)
        self.lower_color = np.array([95, 60, 40])
        self.upper_color = np.array([130, 255, 255])
        
        # Temporal Filter
        self.cx_history = deque(maxlen=5)
        self.cy_history = deque(maxlen=5)

    def get_key(self):
        """Non-blocking keyboard input reading for SSH terminal"""
        tty.setraw(sys.stdin.fileno())
        # Polling timeout of 0.02 matches 50Hz, good for ~30 FPS camera
        rlist, _, _ = select.select([sys.stdin], [], [], 0.02)
        
        if rlist:
            key = sys.stdin.read(1)
            if key == '\x1b':
                key += sys.stdin.read(2) # Read arrow keys completely
        else:
            key = ''
            
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)
        return key

    def run(self):
        msg = """
        [AUTONOMOUS AVOIDANCE ACTIVE]
        Reading Camera and sending P-Control to Arduino...
        ---------------------------
        Up/Down: Adjust Speed
        Left/Right: DISABLED (Vision handles steering)
        's': Save Debug Image
        Space: Emergency Stop (Brakes to 0)
        CTRL-C or 'q': Quit
        
        *** WARNING: CAR WILL START MOVING AT 200 PWM IMMEDIATELY! ***
        """
        print(msg)
        
        # Save terminal settings to restore later
        self.settings = termios.tcgetattr(sys.stdin)
        last_print_time = 0
        last_serial_time = 0
        command_rpm = 0

        try:
            while rclpy.ok():
                # --- A. KEYBOARD CONTROLS (Processed first!) ---
                key = self.get_key()
                
                if key == '\x1b[A': # Up Arrow -> Accelerate
                    self.target_rpm = min(self.target_rpm + 10, 250)
                elif key == '\x1b[B': # Down Arrow -> Decelerate/Reverse
                    self.target_rpm = max(self.target_rpm - 10, -250)
                elif key == ' ': # Spacebar -> Emergency Brake
                    self.target_rpm = 0
                    self.steering = 90
                elif key == 's': # Save debug frame
                    timestamp = time.strftime("%Y%m%d-%H%M%S")
                    filepath = os.path.join(self.save_folder, f"auto_vision_{timestamp}.jpg")
                    # We write the last captured frame
                    if 'frame' in locals():
                        cv2.imwrite(filepath, frame)
                        print(f"\n >>> DEBUG IMAGE SAVED: {filepath} <<< \n")
                elif key == 'q' or key == '\x03': # Quit
                    break

                # --- B. VISION PIPELINE ---
                ret, frame = self.cap.read()
                if not ret:
                    self.get_logger().error("Camera feed lost.")
                    break

                frame = cv2.resize(frame, (640, 480))
                blurred_frame = cv2.GaussianBlur(frame, (11, 11), 0)
                hsv_frame = cv2.cvtColor(blurred_frame, cv2.COLOR_BGR2HSV)
                mask = cv2.inRange(hsv_frame, self.lower_color, self.upper_color)

                kernel = np.ones((5, 5), np.uint8)
                mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=1)
                mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)

                contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                ball_detected = False

                if len(contours) > 0:
                    largest_contour = max(contours, key=cv2.contourArea)
                    if cv2.contourArea(largest_contour) > 500:
                        M = cv2.moments(largest_contour)
                        if M["m00"] != 0:
                            raw_cx = int(M["m10"] / M["m00"])
                            raw_cy = int(M["m01"] / M["m00"])
                            self.cx_history.append(raw_cx)
                            self.cy_history.append(raw_cy)
                            ball_detected = True
                            
                            # Draw for debug images
                            ((x, y), radius) = cv2.minEnclosingCircle(largest_contour)
                            cv2.circle(frame, (int(x), int(y)), int(radius), (0, 255, 255), 2)

                # --- C. ARTIFICIAL POTENTIAL FIELD (REPULSIVE STEERING) ---
                if ball_detected and len(self.cx_history) > 0:
                    smooth_cx = int(sum(self.cx_history) / len(self.cx_history))
                    smooth_cy = int(sum(self.cy_history) / len(self.cy_history))
                    
                    # Distance from center (0 to 320)
                    center_distance = abs(320 - smooth_cx)
                    
                    # 1. REPULSIVE STEERING LOGIC
                    repulsive_force = 35.0 * (1.0 - (center_distance / 320.0))
                    if smooth_cx < 320:
                        raw_steering = 90 + repulsive_force
                    else:
                        raw_steering = 90 - repulsive_force
                    self.steering = int(max(55, min(125, raw_steering)))
                    
                    # 2. ADAPTIVE THROTTLE
                    if self.target_rpm > 0: 
                        speed_penalty = 0.5 * (1.0 - (center_distance / 320.0))
                        command_rpm = int(self.target_rpm * (1.0 - speed_penalty))
                    elif self.target_rpm < 0:
                        speed_penalty = 0.5 * (1.0 - (center_distance / 320.0))
                        command_rpm = int(self.target_rpm * (1.0 - speed_penalty))
                    else:
                        command_rpm = 0
                    
                    cv2.circle(frame, (smooth_cx, smooth_cy), 5, (0, 0, 255), -1)
                    cv2.putText(frame, f"PWM: {self.steering} | Force: {repulsive_force:.1f}", (10, 30),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
                    
                    if time.time() - last_print_time > 0.5:
                        print(f"[*] AVOIDING: Ball X={smooth_cx} | Steer={self.steering} | T-RPM={command_rpm} | Act-RPM={self.actual_rpm}")
                        last_print_time = time.time()
                        
                else:
                    self.cx_history.clear()
                    self.cy_history.clear()
                    self.steering = 90 # Neutral if no ball seen
                    command_rpm = self.target_rpm
                    
                    if time.time() - last_print_time > 1.0:
                        print(f"[ ] CLEAR: Moving straight | Steer=90 | T-RPM={command_rpm} | Act-RPM={self.actual_rpm}")
                        last_print_time = time.time()

                # --- D. SEND COMMANDS TO ARDUINO (Rate Limited!) ---
                # We only send commands 20 times a second so the Arduino doesn't freeze
                current_time = time.time()
                if current_time - last_serial_time > 0.05:
                    command = f"{command_rpm},{self.steering}\n"
                    self.ser.write(command.encode('utf-8'))
                    last_serial_time = current_time

                # --- E. READ ENCODER FEEDBACK FROM ARDUINO ---
                while self.ser.in_waiting > 0:
                    try:
                        incoming_data = self.ser.readline().decode('utf-8').strip()
                        if incoming_data.startswith("RPM:"):
                            parts = incoming_data.split(":")
                            if len(parts) >= 2:
                                self.actual_rpm = float(parts[1].strip())
                    except Exception:
                        pass

        except KeyboardInterrupt:
            pass

        finally:
            # STOP ROBOT BEFORE EXITING
            print("\nShutting down... Stopping motors.")
            self.ser.write(b"0,90\n")
            time.sleep(0.1) # Give Arduino a moment to receive the stop command
            self.ser.close()
            self.cap.release()
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)

def main(args=None):
    rclpy.init(args=args)
    node = AutonomousVisionNode()
    node.run()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
