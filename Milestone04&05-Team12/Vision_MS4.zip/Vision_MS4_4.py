import rclpy
from rclpy.node import Node
import serial
import cv2
import numpy as np
import time
import os
import sys
import select
import termios
import tty
from collections import deque

class AutonomousVisionNode(Node):
    def __init__(self):
        super().__init__('autonomous_vision_node')
        
        # --- 1. SERIAL SETUP (Arduino) ---
        self.arduino_port = '/dev/ttyACM0'
        self.baud_rate = 115200
        try:
            self.ser = serial.Serial(self.arduino_port, self.baud_rate, timeout=0.05)
            self.get_logger().info('Serial connection established with Arduino.')
        except serial.SerialException:
            self.get_logger().error('Could not open serial port. Check Arduino connection!')
            sys.exit(1)
            
        self.base_pwm = 200 # Starts automatically at 200 PWM for forward motion
        self.actual_rpm = 0.0 # Store encoder feedback
        self.steering = 90 # Default straight
        self.prev_avoidance_val = 0.0 # For the Derivative (Kd) controller
        
        # --- 2. CAMERA SETUP ---
        self.cap = cv2.VideoCapture(0)
        if not self.cap.isOpened():
            self.get_logger().error("Could not open webcam.")
            sys.exit(1)
            
        # --- 3. VISION PARAMETERS ---
        self.save_folder = "captured_images"
        if not os.path.exists(self.save_folder):
            os.makedirs(self.save_folder)
            
        # Blue ball color profile
        self.lower_color = np.array([95, 60, 40])
        self.upper_color = np.array([130, 255, 255])
        
        # Temporal Filter
        self.cx_history = deque(maxlen=5)
        self.cy_history = deque(maxlen=5)

    def get_key(self):
        """Non-blocking keyboard input reading for SSH terminal"""
        tty.setraw(sys.stdin.fileno())
        rlist, _, _ = select.select([sys.stdin], [], [], 0.02)
        
        if rlist:
            key = sys.stdin.read(1)
            if key == '\x1b':
                key += sys.stdin.read(2)
        else:
            key = ''
            
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)
        return key

    def run(self):
        msg = """
        [AUTONOMOUS PD AVOIDANCE ACTIVE]
        Reading Camera and sending Aggressive PD-Control...
        ---------------------------
        Up/Down: Adjust Forward/Backward Motor PWM (+10 / -10)
        Left/Right: DISABLED
        's': Save Debug Image
        Space: Emergency Stop (Brakes to 0)
        CTRL-C or 'q': Quit
        """
        print(msg)
        
        self.settings = termios.tcgetattr(sys.stdin)
        last_print_time = 0
        last_serial_time = 0
        command_pwm = 0

        try:
            while rclpy.ok():
                # --- A. KEYBOARD CONTROLS ---
                key = self.get_key()
                if key == '\x1b[A': self.base_pwm = min(self.base_pwm + 10, 255)
                elif key == '\x1b[B': self.base_pwm = max(self.base_pwm - 10, -255)
                elif key == ' ': 
                    self.base_pwm = 0
                    self.steering = 90
                elif key == 's': 
                    timestamp = time.strftime("%Y%m%d-%H%M%S")
                    filepath = os.path.join(self.save_folder, f"auto_vision_{timestamp}.jpg")
                    if 'frame' in locals():
                        cv2.imwrite(filepath, frame)
                        print(f"\n >>> DEBUG IMAGE SAVED: {filepath} <<< \n")
                elif key == 'q' or key == '\x03': break

                # --- B. VISION PIPELINE ---
                ret, frame = self.cap.read()
                if not ret: break

                frame = cv2.resize(frame, (640, 480))
                blurred_frame = cv2.GaussianBlur(frame, (11, 11), 0)
                hsv_frame = cv2.cvtColor(blurred_frame, cv2.COLOR_BGR2HSV)
                mask = cv2.inRange(hsv_frame, self.lower_color, self.upper_color)

                kernel = np.ones((5, 5), np.uint8)
                mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=1)
                mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)

                contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                ball_detected = False

                if len(contours) > 0:
                    largest_contour = max(contours, key=cv2.contourArea)
                    if cv2.contourArea(largest_contour) > 500:
                        M = cv2.moments(largest_contour)
                        if M["m00"] != 0:
                            self.cx_history.append(int(M["m10"] / M["m00"]))
                            self.cy_history.append(int(M["m01"] / M["m00"]))
                            ball_detected = True
                            
                            ((x, y), radius) = cv2.minEnclosingCircle(largest_contour)
                            cv2.circle(frame, (int(x), int(y)), int(radius), (0, 255, 255), 2)

                # --- C. PD REPULSIVE STEERING LOGIC ---
                if ball_detected and len(self.cx_history) > 0:
                    smooth_cx = int(sum(self.cx_history) / len(self.cx_history))
                    smooth_cy = int(sum(self.cy_history) / len(self.cy_history))
                    
                    # Positive = Ball is on Left. Negative = Ball is on Right.
                    raw_center_error = 320 - smooth_cx
                    
                    # 1. ANTI-JITTER BIAS (The "Buridan's Ass" fix)
                    if -30 <= raw_center_error <= 30:
                        center_error = 30
                    else:
                        center_error = raw_center_error
                        
                    # Repulsion is highest (320) in the middle, lowest (0) at the edges
                    repulsion_magnitude = 320 - abs(center_error)
                    direction = 1 if center_error > 0 else -1
                    
                    # 2. PD CONTROLLER GAINS
                    Kp = 0.35  # VERY Aggressive P-Gain
                    Kd = 0.50  # High D-Gain to stop overshoot/twitching
                    
                    P_term = Kp * repulsion_magnitude * direction
                    D_term = Kd * (P_term - self.prev_avoidance_val)
                    self.prev_avoidance_val = P_term
                    
                    raw_steering = 90 + P_term + D_term
                    self.steering = int(max(55, min(125, raw_steering)))
                    
                    # 3. AGGRESSIVE ADAPTIVE THROTTLE
                    if self.base_pwm > 0: 
                        # Brake up to 60% if the obstacle is dead ahead
                        speed_penalty = 0.6 * (repulsion_magnitude / 320.0)
                        command_pwm = int(self.base_pwm * (1.0 - speed_penalty))
                    else:
                        # Don't auto-brake if we are manually reversing
                        command_pwm = self.base_pwm
                    
                    cv2.circle(frame, (smooth_cx, smooth_cy), 5, (0, 0, 255), -1)
                    cv2.putText(frame, f"PWM:{self.steering} | P:{P_term:.1f} D:{D_term:.1f}", (10, 30),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
                    
                    if time.time() - last_print_time > 0.5:
                        print(f"[*] AVOIDING: Ball X={smooth_cx} | Steer={self.steering} | Motor PWM={command_pwm}")
                        last_print_time = time.time()
                        
                else:
                    self.cx_history.clear()
                    self.cy_history.clear()
                    self.prev_avoidance_val = 0.0 # Reset Derivative memory
                    self.steering = 90
                    command_pwm = self.base_pwm
                    
                    if time.time() - last_print_time > 1.0:
                        print(f"[ ] CLEAR: Moving straight | Steer=90 | Motor PWM={command_pwm} | Act-RPM={self.actual_rpm}")
                        last_print_time = time.time()

                # --- D. SEND COMMANDS TO ARDUINO ---
                current_time = time.time()
                if current_time - last_serial_time > 0.05:
                    command = f"{command_pwm},{self.steering}\n"
                    self.ser.write(command.encode('utf-8'))
                    last_serial_time = current_time

                # --- E. READ ENCODER FEEDBACK ---
                while self.ser.in_waiting > 0:
                    try:
                        incoming_data = self.ser.readline().decode('utf-8').strip()
                        if incoming_data.startswith("RPM:"):
                            parts = incoming_data.split(":")
                            if len(parts) >= 2:
                                self.actual_rpm = float(parts[1].strip())
                    except Exception:
                        pass

        except KeyboardInterrupt:
            pass

        finally:
            print("\nShutting down... Stopping motors.")
            self.ser.write(b"0,90\n")
            time.sleep(0.1)
            self.ser.close()
            self.cap.release()
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)

def main(args=None):
    rclpy.init(args=args)
    node = AutonomousVisionNode()
    node.run()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
