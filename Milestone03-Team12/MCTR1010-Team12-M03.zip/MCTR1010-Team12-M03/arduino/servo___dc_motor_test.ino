#include <Servo.h>

// ===== SERVO =====
Servo steering;
int servo_pin = 6;
int center_angle = 90;
int max_offset = 45;

// ===== MOTOR (L298N or similar) =====
int IN1 = 8;
int IN2 = 9;
int ENA = 5;

// ===== ENCODER =====
int encoderA = 2;
int encoderB = 3;

volatile long encoder_count = 0;

unsigned long last_time = 0;
float rpm = 0;

// ===== SETTINGS =====
int pulses_per_rev = 20;  // ⚠️ adjust based on your encoder

// ===== FUNCTIONS =====
void setSteering(int angle) {
  angle = constrain(angle, -max_offset, max_offset);
  steering.write(center_angle + angle);
}

void setMotor(int speed_val) {
  speed_val = constrain(speed_val, -255, 255);

  if (speed_val > 0) {
    digitalWrite(IN1, HIGH);
    digitalWrite(IN2, LOW);
    analogWrite(ENA, speed_val);
  }
  else if (speed_val < 0) {
    digitalWrite(IN1, LOW);
    digitalWrite(IN2, HIGH);
    analogWrite(ENA, -speed_val);
  }
  else {
    digitalWrite(IN1, LOW);
    digitalWrite(IN2, LOW);
    analogWrite(ENA, 0);
  }
}

// Encoder interrupt
void readEncoder() {
  encoder_count++;
}

// ===== SETUP =====
void setup() {
  Serial.begin(115200);  // 🔥 important for ROS later

  // Servo
  steering.attach(servo_pin);
  setSteering(0);  // center

  // Motor pins
  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  pinMode(ENA, OUTPUT);

  // Encoder pins
  pinMode(encoderA, INPUT_PULLUP);
  pinMode(encoderB, INPUT_PULLUP);

  attachInterrupt(digitalPinToInterrupt(encoderA), readEncoder, RISING);

  last_time = millis();

  Serial.println("Ready: send speed,angle (e.g., 150,20)");
}

// ===== LOOP =====
void loop() {

  // ===== SERIAL CONTROL =====
  if (Serial.available() > 0) {

    String data = Serial.readStringUntil('\n');
    int commaIndex = data.indexOf(',');

    if (commaIndex > 0) {

      int speed_val = data.substring(0, commaIndex).toInt();
      int angle = data.substring(commaIndex + 1).toInt();

      setSteering(angle);
      setMotor(speed_val);

      Serial.print("Speed: ");
      Serial.print(speed_val);
      Serial.print(" | Angle: ");
      Serial.println(angle);
    }

    // clear buffer
    while (Serial.available()) Serial.read();
  }

  // ===== RPM CALCULATION =====
  if (millis() - last_time >= 1000) {

    rpm = (encoder_count * 60.0) / pulses_per_rev;

    Serial.print("RPM: ");
    Serial.println(rpm);

    encoder_count = 0;
    last_time = millis();
  }
}
