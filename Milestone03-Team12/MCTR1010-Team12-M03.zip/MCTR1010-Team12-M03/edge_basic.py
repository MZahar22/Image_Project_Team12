import cv2
import numpy as np
import serial
import time

# Initialize camera
cap = cv2.VideoCapture(0, cv2.CAP_V4L2)

cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

# Initialize serial communication
ser = serial.Serial('/dev/ttyACM0', 115200)
time.sleep(2)

# Threshold for decision
THRESHOLD = 10000

try:
    while True:
        ret, frame = cap.read()
        if not ret:
            print("Failed to capture")
            break

        # Convert to grayscale
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # Improve contrast
        gray = cv2.equalizeHist(gray)
        gray = cv2.convertScaleAbs(gray, alpha=1.2, beta=10)

        # Blur
        blur = cv2.GaussianBlur(gray, (5, 5), 0)

        # Edge detection
        edges = cv2.Canny(blur, 50, 150)

        # Count edges
        edge_count = np.sum(edges > 0)

        print("Edge Count:", edge_count)

        # Decision logic
        if edge_count > THRESHOLD:
            ser.write(b"120,0\n")   # forward
            print("FORWARD")
        else:
            ser.write(b"-80,0\n")   # backward
            print("BACKWARD")

except KeyboardInterrupt:
    print("\nManual stop (CTRL+C)")

finally:
    print("Stopping car safely...")
    ser.write(b"0,0\n")   # STOP
    cap.release()
    ser.close()
